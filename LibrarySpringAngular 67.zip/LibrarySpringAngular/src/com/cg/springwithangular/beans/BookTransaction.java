package com.cg.springwithangular.beans;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;


@Entity
@Table(name="Library_angular_book_Transaction")
public class BookTransaction {
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="seq")
	@SequenceGenerator(name="seq",sequenceName="seq_Library_springAng_TrsnId",
				allocationSize=1)
	private int transaction_id;
	@ManyToOne
	@JoinColumn(name="stud_id")
	private Student student;
	@ManyToOne
	@JoinColumn(name="lib_id")
	private Librarian librarian;
	@ManyToOne
	@JoinColumn(name="book_id")
	private Book book;
	@Column(name="request_date")
	private Date requestDate;
	@Column(name="issue_date")
	private Date issueDate;
	@Column(name="return_date")
	private Date returnDate;
	
	
	
	public BookTransaction() {
		super();
	}
	public int getTransaction_id() {
		return transaction_id;
	}
	public void setTransaction_id(int transaction_id) {
		this.transaction_id = transaction_id;
	}
	public Student getStudent() {
		return student;
	}
	public void setStudent(Student student) {
		this.student = student;
	}
	public Librarian getLibrarian() {
		return librarian;
	}
	public void setLibrarian(Librarian librarian) {
		this.librarian = librarian;
	}
	public Book getBook() {
		return book;
	}
	public void setBook(Book book) {
		this.book = book;
	}
	public Date getRequestDate() {
		return requestDate;
	}
	public void setRequestDate(Date requestDate) {
		this.requestDate = requestDate;
	}
	public Date getIssueDate() {
		return issueDate;
	}
	public void setIssueDate(Date issueDate) {
		this.issueDate = issueDate;
	}
	public Date getReturnDate() {
		return returnDate;
	}
	public void setReturnDate(Date returnDate) {
		this.returnDate = returnDate;
	}
	public BookTransaction(Student student, Librarian librarian, Book book,
			Date requestDate, Date issueDate, Date returnDate) {
		super();
		this.student = student;
		this.librarian = librarian;
		this.book = book;
		this.requestDate = requestDate;
		this.issueDate = issueDate;
		this.returnDate = returnDate;
	}
	@Override
	public String toString() {
		return "BookTransaction [transaction_id=" + transaction_id
				+ ", student=" + student + ", librarian=" + librarian
				+ ", book=" + book + ", requestDate=" + requestDate
				+ ", issueDate=" + issueDate + ", returnDate=" + returnDate
				+ "]";
	}
	
	
	
	
}
