package com.cg.springwithangular.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;





import com.cg.springwithangular.beans.Book;
//import com.cg.library.util.PasswordUtils;
import com.cg.springwithangular.beans.Librarian;
import com.cg.springwithangular.beans.Login;
import com.cg.springwithangular.beans.Student;

@Repository("libdao")
public class LibraryDaoImpl implements ILibraryDao {
	@PersistenceContext
	EntityManager entityManager;

//	public Student loginAsStudent1(Login login) {
//		Login authenticateLogin ;
//		String qStr1 ;
//		String qStr = "SELECT login FROM Login login WHERE login.userName = :uname AND password = :pass AND authority = :auth ";
//		 TypedQuery<Login> query = entityManager.createQuery(qStr, Login.class);
//		 query.setParameter("uname", login.getUserName());
//		 query.setParameter("pass", login.getPassword());
//		 query.setParameter("auth", "student");
//		 
//		 System.out.println("in the dao " + login);
//		 try{
//			 authenticateLogin = (Login)query.getSingleResult();
//			 System.out.println(authenticateLogin);
//			 if(authenticateLogin != null)
//			 {
//				 qStr1 = "SELECT student FROM Student student WHERE student.login.getUserName() = :uname";
//				 TypedQuery<Student> query1 = entityManager.createQuery(qStr1, Student.class);
//				 query.setParameter("uname", login.getUserName());
//				 return (Student)query1.getSingleResult();
//			 }
//			 else
//				 return null;
//		 }catch (NoResultException nre){
//			 return null;
//			 }
//		
//	}
	@Override
	public Student loginAsStudent(Login login) {
		Student student;
		Login authenticateLogin ;
		authenticateLogin = entityManager.find(Login.class, login.getUserName());
		 System.out.println("in the dao " + login);
		 System.out.println("find login  result " + authenticateLogin);
		 if(authenticateLogin != null)
		 {
			 boolean validAuthority = authenticateLogin.getAuthority().equalsIgnoreCase(login.getAuthority());
			 boolean validPassword = authenticateLogin.getPassword().equals(login.getPassword());
			 if(validAuthority && validPassword)
			 {
				 System.out.println("login successfull");
				 student = findStudent(login.getUserName());
				 return student;
			 } 
			 else
				 return null;
			
		 }
		 else
			 return null;
		 
		
	}
	@Override
	public Librarian loginAsLibrarian(Login login) {
		Librarian librarian;
		Login authenticateLogin ;
		authenticateLogin = entityManager.find(Login.class, login.getUserName());
		 System.out.println("in the dao " + login);
		 System.out.println("find login result " + authenticateLogin);
		 if(authenticateLogin != null)
		 {
			 boolean validAuthority = authenticateLogin.getAuthority().equalsIgnoreCase(login.getAuthority());
			 boolean validPassword = authenticateLogin.getPassword().equals(login.getPassword());
			 if(validAuthority && validPassword)
			 {
				 System.out.println("login successfull");
				 librarian = findLibrarian(login.getUserName());
				 return librarian;
			 } 
			 else
				 return null;
			
		 }
		 else
			 return null;
	}
	@Override
	public Student findStudent(String userName) { 
		
		System.out.println("in the findStudent " + userName);
		String qStr = "SELECT student FROM Student student WHERE student.login.userName = :uname ";
		 TypedQuery<Student> query = entityManager.createQuery(qStr, Student.class);
		 query.setParameter("uname", userName);
		 Student student  = query.getSingleResult();
		if(student !=null)
		{
			return student;
		}
		else
			return null;
		
	}
	@Override
	public Librarian findLibrarian(String userName) {

		System.out.println("in the findLibrarian " + userName);
		String qStr = "SELECT librarian FROM Librarian librarian WHERE librarian.login.userName = :uname ";
		 TypedQuery<Librarian> query = entityManager.createQuery(qStr, Librarian.class);
		 query.setParameter("uname", userName);
		 Librarian librarian  = query.getSingleResult();
		if(librarian !=null)
		{
			return librarian;
		}
		else
			return null;
	}
	@Override
	public void addBook(Book book) {
		entityManager.persist(book);
		entityManager.flush();
	}
	@Override
	public List<Book> getAllBooks() {
		Query queryOne = entityManager.createQuery("FROM Book");
		List<Book> allBooks = queryOne.getResultList();
		return allBooks;
	}
}
