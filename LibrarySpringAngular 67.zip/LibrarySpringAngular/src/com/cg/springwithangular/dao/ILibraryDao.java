package com.cg.springwithangular.dao;

import java.util.List;

import com.cg.springwithangular.beans.Book;
import com.cg.springwithangular.beans.Librarian;
import com.cg.springwithangular.beans.Login;
import com.cg.springwithangular.beans.Student;

public interface ILibraryDao {
	Student loginAsStudent(Login login);
	Librarian loginAsLibrarian(Login login);
	
	Student findStudent(String userName);
	Librarian findLibrarian(String userName);
	
	public List<Book> getAllBooks();
	void addBook(Book book);
}
