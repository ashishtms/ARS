package com.cg.springwithangular.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.springwithangular.beans.Book;
import com.cg.springwithangular.beans.Librarian;
import com.cg.springwithangular.beans.Login;
import com.cg.springwithangular.beans.Student;
import com.cg.springwithangular.dao.ILibraryDao;


@Transactional
@Service("libservice")
public class LibraryServiceImpl implements ILibraryService {
	@Autowired
	ILibraryDao libdao;

	@Override
	public Student loginAsStudent(Login login) {
		System.out.println("In service  input " + login);
		return libdao.loginAsStudent(login);
	}

	@Override
	public Librarian loginAsLibrarian(Login login) {
		return libdao.loginAsLibrarian(login);
	}



	@Override
	public void addBook(Book book) {

		libdao.addBook(book);
	}



	@Override
	public List<Book> getAllBooks() {
		// TODO Auto-generated method stub
		return libdao.getAllBooks();
	}
}
