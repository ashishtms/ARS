package com.cg.springwithangular.service;

import java.util.List;

import com.cg.springwithangular.beans.Book;
import com.cg.springwithangular.beans.Librarian;
import com.cg.springwithangular.beans.Login;
import com.cg.springwithangular.beans.Student;

public interface ILibraryService {
	
	Student loginAsStudent(Login login);
	Librarian loginAsLibrarian(Login login);
	
	public List<Book> getAllBooks();
	void addBook(Book book);
}
