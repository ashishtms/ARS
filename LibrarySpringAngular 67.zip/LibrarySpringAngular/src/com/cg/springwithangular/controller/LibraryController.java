package com.cg.springwithangular.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.springwithangular.beans.Book;
import com.cg.springwithangular.beans.Login;
import com.cg.springwithangular.beans.Student;
import com.cg.springwithangular.service.ILibraryService;

@RestController
public class LibraryController {
	@Autowired
	ILibraryService libservice;

	@RequestMapping(value = "/studentLogin", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE, headers = "Accept=application/json", method = RequestMethod.POST)
	public Student loginAsStudent(@RequestBody Login login) {

		System.out.println("Login as student");
		System.out.println("Input is " + login);
		Student student = libservice.loginAsStudent(login);
		System.out.println(student);
		return student;
	}

	@RequestMapping(value = "/book/add/", consumes = MediaType.APPLICATION_JSON_VALUE, headers = "Accept=application/json", method = RequestMethod.POST)
	public List<Book> addBook(@RequestBody Book book) {

		System.out.println("In the add book");
		System.out.println("Input is  : " + book);
		libservice.addBook(book);
		return libservice.getAllBooks();
	}
	
	
	@RequestMapping(value = "/book/getAll",method = RequestMethod.GET,headers="Accept=application/json")
	public List<Book> getAllBooks(Model model) {
		System.out.println("In get all books");
		return libservice.getAllBooks();
	}
}
